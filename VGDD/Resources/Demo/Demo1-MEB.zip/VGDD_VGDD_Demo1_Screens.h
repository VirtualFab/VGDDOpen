#ifndef	_VGDD_SCREENS_H_
#define	 _VGDD_SCREENS_H_
WORD VGDD_VGDD_Demo1_MsgCallback(WORD objMsg, OBJ_HEADER *pObj, GOL_MSG *pMsg);
WORD VGDD_VGDD_Demo1_DrawCallback(void);
extern GOL_SCHEME* GOLScheme_Demo;
void CreateScheme_Demo(void);
extern GOL_SCHEME* GOLScheme_Demo2;
void CreateScheme_Demo2(void);
extern GOL_SCHEME* GOLScheme_Demo3;
void CreateScheme_Demo3(void);
extern GOL_SCHEME* GOLScheme_BigFont;
void CreateScheme_BigFont(void);
extern GOL_SCHEME* GOLScheme_Minerva;
void CreateScheme_Minerva(void);
extern GOL_SCHEME* GOLScheme_Nasalization;
void CreateScheme_Nasalization(void);
extern GOL_SCHEME* GOLScheme_Trebuchet;
void CreateScheme_Trebuchet(void);
extern GOL_SCHEME* GOLScheme_PalaceScript;
void CreateScheme_PalaceScript(void);
extern GOL_SCHEME* GOLScheme_TerminatorTwo;
void CreateScheme_TerminatorTwo(void);
extern GOL_SCHEME* GOLScheme_Gauge;
void CreateScheme_Gauge(void);
void CreateSplash(void);
#define ID_Splash_Picture1   1
void CreateMain(void);
#define ID_Main_Picture6   6
#define ID_Main_Button5   7
#define ID_Main_Picture2   8
#define ID_Main_Picture3   9
#define ID_Main_Picture4   10
#define ID_Main_Picture5   11
#define ID_Main_Button2   12
#define ID_Main_Button4   13
void CreateDemo1(void);
#define ID_Demo1_Picture10   14
#define ID_Demo1_Picture4   15
#define ID_Demo1_Window1   16
#define ID_Demo1_Slider1   17
#define ID_Demo1_Meter1   18
#define ID_Demo1_Picture1   19
#define ID_Demo1_Picture7   20
#define ID_Demo1_Button1   21
#define ID_Demo1_Picture5   22
void CreateDemo2(void);
#define ID_Demo2_Picture6   23
#define ID_Demo2_Window1   24
#define ID_Demo2_RoundDial1   25
#define ID_Demo2_Button1   26
extern XCHAR Demo2_StaticText1_Text[];
#define ID_Demo2_StaticText1   27
#define ID_Demo2_Picture4   28
#define ID_Demo2_Picture5   29
void CreateDemo3(void);
#define ID_Demo3_Picture7   30
#define ID_Demo3_Window1   31
#define ID_Demo3_Slider1   32
#define ID_Demo3_ProgressBar1   33
#define ID_Demo3_ProgressBar2   34
#define ID_Demo3_ProgressBar3   35
#define ID_Demo3_ProgressBar4   36
#define ID_Demo3_ProgressBar5   37
#define ID_Demo3_Button1   38
#define ID_Demo3_Picture6   39
#define ID_Demo3_Picture4   40
#define ID_Demo3_Picture5   41
void CreateDemo4(void);
#define ID_Demo4_Picture6   42
#define ID_Demo4_Button1   43
#define ID_Demo4_Button2   44
#define ID_Demo4_Button3   45
#define ID_Demo4_Button4   46
#define ID_Demo4_Button5   47
#define ID_Demo4_Button6   48
#define ID_Demo4_Button7   49
#define ID_Demo4_Button8   50
#define ID_Demo4_Button9   51
#define ID_Demo4_Button10   52
#define ID_Demo4_Button11   53
#define ID_Demo4_Button12   54
extern XCHAR Demo4_EditBox1_Text[];
#define ID_Demo4_EditBox1   55
#define ID_Demo4_Button13   56
#define ID_Demo4_Picture7   57
#define ID_Demo4_Picture4   58
#define ID_Demo4_Picture5   59
void CreateDemo5(void);
#define ID_Demo5_SuperGauge1   60
#define ID_Demo5_Slider1   61
#define ID_Demo5_Picture4   62
#define ID_Demo5_Picture5   63
void CreateFontsDemo(void);
#define ID_FontsDemo_StaticText1   64
#define ID_FontsDemo_StaticText2   65
#define ID_FontsDemo_StaticText3   66
#define ID_FontsDemo_StaticText4   67
#define ID_FontsDemo_StaticText5   68
#define ID_FontsDemo_StaticText6   69
#define ID_FontsDemo_Button1   70
#define ID_FontsDemo_Picture4   71
#define ID_FontsDemo_Picture5   72
extern const IMAGE_FLASH bmpclockW;
extern const IMAGE_FLASH bmpburnW;
extern const IMAGE_FLASH bmppinW;
extern const IMAGE_FLASH bmpleft;
extern const IMAGE_FLASH bmpright;
extern const IMAGE_FLASH bmpgalleryW;
extern const IMAGE_FLASH bmpforrstW;
extern const IMAGE_FLASH bmpfilerW;
extern const IMAGE_FLASH bmpdialerW;
extern const IMAGE_FLASH bmpnewsW;
extern const IMAGE_FLASH bmpskymapW;
extern const IMAGE_FLASH bmpVirtualF;
#define	NUM_VGDD_SCREENS	8
#define SCREENSTATE_INIT CREATE_SPLASH
#endif // ifndef _VGDD_SCREENS_H_
