// *****************************************************************************
// VGDD Skeleton
// Hardware specific definitions
// *****************************************************************************
// FileName:        HardwareProfile.h for VGDD Project VGDD_Demo1
// Dependencies:    none
// Processor:       Generated for PIC32 by VGDD 3.5Beta1 MplabX Wizard
// Compiler:        C32
// Company:         VirtualFab, parts from Microchip Technology Incorporated
//
// VirtualFab Software License Agreement:
//
// Copyright 2012 Virtualfab - All rights reserved.
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
// Redistributions of source code must retain the above and following copyright 
// notices, this list of conditions and the following disclaimer.
// Neither the name of Fabio Violino or Virtualfab may be used to endorse or promote 
// products derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES,
// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
// IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
// THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
// Microchip's Software License Agreement:
//
// Copyright © 2012 Microchip Technology Inc.  All rights reserved.
// Microchip licenses to you the right to use, modify, copy and distribute
// Software only when embedded on a Microchip microcontroller or digital
// signal controller, which is integrated into your product or third party
// product (pursuant to the sublicense terms in the accompanying license
// agreement).
//
// You should refer to the license agreement accompanying this Software
// for additional information regarding your rights and obligations.
//
// SOFTWARE AND DOCUMENTATION ARE PROVIDED “AS IS” WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY
// OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR
// PURPOSE. IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR
// OBLIGATED UNDER CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION,
// BREACH OF WARRANTY, OR OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT
// DAMAGES OR EXPENSES INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL,
// INDIRECT, PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA,
// COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY
// CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
// OR OTHER SIMILAR COSTS.
//
// Author               Date        Comment
//
// VirtualFab        2012/01/28     Moved everything into MPLABX/MplabXTemplates.xml
// VirtualFab        2012/02/13     Fully working version
// *****************************************************************************

#ifndef __HARDWARE_PROFILE_H
    #define __HARDWARE_PROFILE_H

    #include "Compiler.h"

// VGDD_MPLABX_WIZARD_START_SECTION: HardwareProfileHead *** DO NOT DELETE THIS LINE! ***
#include <plib.h>

#define GetSystemClock()        (80000000ul)
#define GetPeripheralClock()    (GetSystemClock() / (1 << OSCCONbits.PBDIV))
#define GetInstructionClock()   (GetSystemClock())
#define PIC32_USB_SK
#define USE_USB_INTERFACE
//#define ENABLE_USB_MSD_DEMO
#define USE_COMM_PKT_MEDIA_USB
#define MEB_BOARD
#define USE_16BIT_PMP
#define GFX_USE_DISPLAY_CONTROLLER_SSD1926
#define USE_XC2C64A                // use the CPLD on the board    
#define USE_ACCELEROMETER_BMA150   // use the accelerometer module    
#define USE_JOYSTICK_MEB           // use the joystick
#define USE_SST25VF016             // use the 16 Mbit SPI Serial Flash
#define GFX_USE_DISPLAY_PANEL_TFT_G240320LTSW_118W_E	
#define USE_TOUCHSCREEN_RESISTIVE  // use 4-wire resistive touch screen driver



// VGDD_MPLABX_WIZARD_END_SECTION *** DO NOT DELETE THIS LINE! ***

// VGDD_MPLABX_WIZARD_START_SECTION: HardwareProfile *** DO NOT DELETE THIS LINE! ***
#define tris_self_power     TRISAbits.TRISA2    // Input
#define self_power          1
#define tris_usb_bus_sense  TRISBbits.TRISB5    // Input
#define USB_BUS_SENSE       U1OTGSTATbits.SESVD // Special considerations required if using SESVD for this purpose.  See documentation.
#define COMM_PKT_RX_MAX_SIZE    (1024)

#define TOUCH_ADC_INPUT_SEL   AD1CHS      
#define TOUCH_ADC_START AD1CON1bits.SAMP 
#define TOUCH_ADC_DONE  AD1CON1bits.DONE

#if !defined(MEB_BOARD) & !defined(GFX_PICTAIL_LCC) 
#define ADC_XPOS		ADC_CH0_POS_SAMPLEA_AN11
#define ADC_YPOS		ADC_CH0_POS_SAMPLEA_AN10
#define ADC_TEMP		ADC_CH0_POS_SAMPLEA_AN4
#define ADPCFG_XPOS		AD1PCFGbits.PCFG11
#define ADPCFG_YPOS		AD1PCFGbits.PCFG10
#define LAT_XPOS		LATBbits.LATB11
#define TRIS_XPOS		TRISBbits.TRISB11
#define LAT_XNEG		LATDbits.LATD9
#define TRIS_XNEG		TRISDbits.TRISD9
#define LAT_YPOS		LATBbits.LATB10
#define TRIS_YPOS		TRISBbits.TRISB10
#define LAT_YNEG		LATDbits.LATD8
#define TRIS_YNEG		TRISDbits.TRISD8

// Definitions for reset pin
#define DisplayResetConfig()        TRISCCLR = _TRISC_TRISC1_MASK    
#define DisplayResetEnable()        LATCCLR = _LATC_LATC1_MASK
#define DisplayResetDisable()       LATCSET = _LATC_LATC1_MASK

// Definitions for RS pin
#define DisplayCmdDataConfig()      TRISCCLR = _TRISC_TRISC2_MASK
#define DisplaySetCommand()         LATCCLR = _LATC_LATC2_MASK
#define DisplaySetData()            LATCSET = _LATC_LATC2_MASK

// Definitions for CS pin
#define DisplayConfig()             TRISDCLR = _TRISD_TRISD10_MASK
#define DisplayEnable()             LATDCLR = _LATD_LATD10_MASK
#define DisplayDisable()            LATDSET = _LATD_LATD10_MASK

// Definitions for FLASH CS pin
#define DisplayFlashConfig()          
#define DisplayFlashEnable()        
#define DisplayFlashDisable()       

// Definitions for POWER ON pin
#define DisplayPowerConfig()        
#define DisplayPowerOn()            
#define DisplayPowerOff()            
        
// Definitions for backlight control pin
#define DisplayBacklightConfig()    (TRISDbits.TRISD0 = 0)  
#define DisplayBacklightOn()        (LATDbits.LATD0 = BACKLIGHT_ENABLE_LEVEL)
#define DisplayBacklightOff()       (LATDbits.LATD0 = BACKLIGHT_DISABLE_LEVEL)   
#endif
// ********************************************************************
// * HARDWARE PROFILE FOR THE SPI FLASH MEMORY
// ********************************************************************
// this is dependent on the Starter Kit used
#if defined (PIC32_GP_SK) || defined (PIC32_USB_SK) || defined (dsPIC33E_SK)
	#define SST25_SPI_CHANNEL 2
#elif defined (PIC32_ETH_SK)
	#define SST25_SPI_CHANNEL 4
#else
	#error "Please define the starter kit that you are using"
#endif

/* Define all the SPI channels that will be used here.
    These will be used to determine how the SPI Driver (drv_spi)
    will be compiled.
*/
#if (SST25_SPI_CHANNEL == 1)
    #define SPI_CHANNEL_1_ENABLE
#elif (SST25_SPI_CHANNEL == 2)
    #define SPI_CHANNEL_2_ENABLE
#elif (SST25_SPI_CHANNEL == 3)
    #define SPI_CHANNEL_3_ENABLE
#elif (SST25_SPI_CHANNEL == 4)
    #define SPI_CHANNEL_4_ENABLE
#endif


// Chip Select, SCLK, SDI and SDO signals used 
#if defined (GFX_PICTAIL_V3) || defined (GFX_PICTAIL_V3E) || defined(GFX_PICTAIL_LCC)
    #if defined(__dsPIC33FJ128GP804__) || defined(__PIC24HJ128GP504__)
        #define SST25_CS_TRIS   TRISAbits.TRISA8
        #define SST25_CS_LAT    LATAbits.LATA8
        #define SST25_SCK_TRIS  TRISCbits.TRISC2
        #define SST25_SDO_TRIS  TRISCbits.TRISC0
        #define SST25_SDI_TRIS  TRISCbits.TRISC1
    #else
        #define SST25_CS_TRIS   TRISDbits.TRISD1
        #define SST25_CS_LAT    LATDbits.LATD1
        #define SST25_SCK_TRIS  TRISGbits.TRISG6
        #define SST25_SDO_TRIS  TRISGbits.TRISG8
        #define SST25_SDI_TRIS  TRISGbits.TRISG7
        #if defined (__dsPIC33E__) || defined(__PIC24E__)
            #define SST25_SCK_LAT  	LATGbits.LATG6
	    #define SST25_SCK_ANS   ANSELGbits.ANSG6
	    #define SST25_SDO_ANS   ANSELGbits.ANSG8
	    #define SST25_SDO_LAT  	LATGbits.LATG8
	    #define SST25_SDI_LAT  	LATGbits.LATG7  
	    #define SST25_SDI_ANS   ANSELGbits.ANSG7       		
    	#else            
            #define SST25_SDI_ANS   ANSGbits.ANSG7
    	#endif
    #endif
#elif defined (PIC24FJ256DA210_DEV_BOARD)
    #define SST25_CS_TRIS   TRISAbits.TRISA14
    #define SST25_CS_LAT    LATAbits.LATA14
    #define SST25_SCK_TRIS  TRISDbits.TRISD8
    #define SST25_SDO_TRIS  TRISBbits.TRISB1
    #define SST25_SDI_TRIS  TRISBbits.TRISB0
    #define SST25_SDI_ANS   ANSBbits.ANSB0
    #define SST25_SDO_ANS   ANSBbits.ANSB1
#elif defined (MEB_BOARD)
    // this is dependent on the Starter Kit used
    // define the CPLD SPI selection and chip select     
    #if defined(__dsPIC33E__) || defined(__PIC24E__)
        #if (SST25_SPI_CHANNEL == 2)
            #define SPI_FLASH_CHANNEL   CPLD_SPI2
            #define SST25_CS_TRIS   TRISGbits.TRISG9    // SPI slave select, Input or Output selection.
            #define SST25_CS_LAT    LATGbits.LATG9      // SPI slave select I/O pin latch.
            #define SST25_CS_ANS    ANSELGbits.ANSG9    // SPI slave select I/O pin analog/digital selection.
            #define SST25_SCK_TRIS   TRISGbits.TRISG6    // SPI clock , Input or Output selection.
            #define SST25_SCK_LAT    LATGbits.LATG6      // SPI clock, I/O pin latch.
            #define SST25_SCK_ANS    ANSELGbits.ANSG6    // SPI clock , I/O pin analog/digital selection.
            #define SST25_SDO_TRIS   TRISGbits.TRISG8    // SPI data out , Input or Output selection.
            #define SST25_SDO_LAT    LATGbits.LATG8      // SPI data out,  I/O pin latch.
            #define SST25_SDO_ANS    ANSELGbits.ANSG8    // SPI data out, I/O pin analog/digital selection.
            #define SST25_SDI_TRIS  TRISGbits.TRISG7	 // SPI data in , Input or Output selection.
            #define SST25_SDI_LAT    LATGbits.LATG7      // SPI data in,  I/O pin latch.
            #define SST25_SDI_ANS    ANSELGbits.ANSG7    // SPI data in, I/O pin analog/digital selection.
        #else
            #error "When using dsPIC33E or PIC24E starter kits, MultiMedia Expansion Board (MEB) needs to use SPI channel 2 (SST25_SPI_CHANNEL == 2) for for SPI Flash"
        #endif
    #else
        #if (SST25_SPI_CHANNEL == 2)
            #define SST25_CS_TRIS       TRISGbits.TRISG9
            #define SST25_CS_LAT        LATGbits.LATG9
            #define SPI_FLASH_CHANNEL   CPLD_SPI2
        #elif (SST25_SPI_CHANNEL == 3)
            #define SST25_CS_TRIS       TRISGbits.TRISG9
            #define SST25_CS_LAT        LATGbits.LATG9
            #define SPI_FLASH_CHANNEL   CPLD_SPI2A
        #elif (SST25_SPI_CHANNEL == 4)
            #define SST25_CS_TRIS       TRISFbits.TRISF12
            #define SST25_CS_LAT        LATFbits.LATF12
            #define SPI_FLASH_CHANNEL   CPLD_SPI3A
        #else
            #error "MultiMedia Expansion Board (MEB) needs to use SPI channels 2,3 or 4 (SST25_SPI_CHANNEL == 2, 3 or 4) for for SPI Flash"
        #endif
    #endif
#endif
#define SPIFlashConfigurePins() { \
	SST25_SDO_ANS  = 0; \
	SST25_SDI_ANS  = 0; \
	SST25_CS_LAT   = 1; \
	SST25_CS_TRIS  = 0; \
	SST25_SCK_TRIS = 0; \
	SST25_SDO_TRIS = 0; \
	SST25_SDI_TRIS = 1; \
}

// ********************************************************************
// * HARDWARE PROFILE FOR THE RESISTIVE TOUCHSCREEN 
// ********************************************************************
#define USE_TOUCHSCREEN_RESISTIVE         // use 4-wire resistive touch screen driver
#define TOUCH_ADC_INPUT_SEL   AD1CHS      
#define TOUCH_ADC_START       AD1CON1bits.SAMP 
#define TOUCH_ADC_DONE        AD1CON1bits.DONE
#define ADC_XPOS    ADC_CH0_POS_SAMPLEA_AN11
#define ADC_YPOS    ADC_CH0_POS_SAMPLEA_AN14
#define ADPCFG_XPOS AD1PCFGbits.PCFG11
#define ADPCFG_YPOS AD1PCFGbits.PCFG14
#define LAT_XPOS    LATBbits.LATB11
#define TRIS_XPOS   TRISBbits.TRISB11
#define LAT_XNEG    LATBbits.LATB13
#define TRIS_XNEG   AD1PCFGbits.PCFG13 = 1, TRISBbits.TRISB13
#define LAT_YPOS    LATBbits.LATB14
#define TRIS_YPOS   TRISBbits.TRISB14
#define LAT_YNEG    LATBbits.LATB12 
#define TRIS_YNEG   AD1PCFGbits.PCFG12 = 1, TRISBbits.TRISB12

// ********************************************************************
// * Configuration for the CPLD
// ********************************************************************
#define GRAPHICS_HW_CONFIG     CPLD_GFX_CONFIG_16BIT

// Definitions for reset pin
#define DisplayResetConfig()           TRISACLR = _TRISA_TRISA10_MASK    
#define DisplayResetEnable()           LATACLR = _LATA_LATA10_MASK
#define DisplayResetDisable()          LATASET = _LATA_LATA10_MASK
	
// Definitions for RS pin
#define DisplayCmdDataConfig()         AD1PCFGSET = _AD1PCFG_PCFG10_MASK, TRISBCLR = _TRISB_TRISB10_MASK
#define DisplaySetCommand()            LATBCLR = _LATB_LATB10_MASK
#define DisplaySetData()               LATBSET = _LATB_LATB10_MASK
	
// Definitions for CS pin
#define DisplayConfig()                TRISGCLR = _TRISG_TRISG13_MASK
#define DisplayEnable()                LATGCLR = _LATG_LATG13_MASK
#define DisplayDisable()               LATGSET = _LATG_LATG13_MASK
	
// Definitions for FLASH CS pin
#define DisplayFlashConfig()          
#define DisplayFlashEnable()        
#define DisplayFlashDisable()       
	
// Definitions for POWER ON pin
#define DisplayPowerConfig()        
#define DisplayPowerOn()            
#define DisplayPowerOff()           
	
#define DisplayBacklightConfig()    (TRISDbits.TRISD0 = 0)  
#define DisplayBacklightOn()        (LATDbits.LATD0 = BACKLIGHT_ENABLE_LEVEL)
#define DisplayBacklightOff()       (LATDbits.LATD0 = BACKLIGHT_DISABLE_LEVEL)   

// ********************************************************************
// * Touch Screen Non-Volatile Memory Storage Macros
// ********************************************************************
#define ADDRESS_RESISTIVE_TOUCH_VERSION	(unsigned long)0xFFFFFFFE
#define ADDRESS_RESISTIVE_TOUCH_ULX   (unsigned long)0xFFFFFFFC
#define ADDRESS_RESISTIVE_TOUCH_ULY   (unsigned long)0xFFFFFFFA
#define ADDRESS_RESISTIVE_TOUCH_URX   (unsigned long)0xFFFFFFF8
#define ADDRESS_RESISTIVE_TOUCH_URY   (unsigned long)0xFFFFFFF6

#define ADDRESS_RESISTIVE_TOUCH_LLX   (unsigned long)0xFFFFFFF4
#define ADDRESS_RESISTIVE_TOUCH_LLY   (unsigned long)0xFFFFFFF2
#define ADDRESS_RESISTIVE_TOUCH_LRX   (unsigned long)0xFFFFFFF0
#define ADDRESS_RESISTIVE_TOUCH_LRY   (unsigned long)0xFFFFFFEE

#define NVMSectorErase                  ((NVM_SECTORERASE_FUNC)&SST25SectorErase)
#define NVMWrite                        ((NVM_WRITE_FUNC)&SST25WriteWord)
#define NVMRead                         ((NVM_READ_FUNC)&SST25ReadWord)

/*********************************************************************
* Configuration for the CPLD
*********************************************************************/
#if defined(__PIC32MX__)
	#include <plib.h>
	#ifdef USE_16BIT_PMP
	#define GRAPHICS_HW_CONFIG     CPLD_GFX_CONFIG_16BIT
	#else
	#define GRAPHICS_HW_CONFIG     CPLD_GFX_CONFIG_8BIT
	#endif
#endif // #ifdef (__PIC32MX__)
#if defined(__dsPIC33E__) || defined (__PIC24E__)
	#ifdef USE_16BIT_PMP
	#define GRAPHICS_HW_CONFIG     CPLD_GFX_CONFIG_16BIT
	#else
	#define GRAPHICS_HW_CONFIG     CPLD_GFX_CONFIG_8BIT
	#endif

	#if defined (USE_XC2C64A)
		// If using the CPLD.
		 #define BIT_15                       (1 << 15)
		 #define BIT_14                       (1 << 14)
		 #define BIT_13                       (1 << 13)
		 #define BIT_12                       (1 << 12)
		 #define BIT_11                       (1 << 11)
		 #define BIT_10                       (1 << 10)
		 #define BIT_9                        (1 << 9)
		 #define BIT_8                        (1 << 8)
		 #define BIT_7                        (1 << 7)
		 #define BIT_6                        (1 << 6)
		 #define BIT_5                        (1 << 5)
		 #define BIT_4                        (1 << 4)
		 #define BIT_3                        (1 << 3)
		 #define BIT_2                        (1 << 2)
		 #define BIT_1                        (1 << 1)
		 #define BIT_0                        (1 << 0)

		typedef	unsigned char		__uint8_t;
		#define	uint8_t		__uint8_t

		 typedef struct
		{
				volatile unsigned int	tris;
				volatile unsigned int	port;
				volatile unsigned int	lat;
				volatile unsigned int	odc;
				volatile unsigned int	cnen;
				volatile unsigned int	cnpu;
				volatile unsigned int	cnpd;
				volatile unsigned int	ansel;
		}PortRegMap;	// port registers layout

		#define IOPORT_A (unsigned int*)&TRISA
		#define IOPORT_B (unsigned int*)&TRISB
		#define IOPORT_C (unsigned int*)&TRISC
		#define IOPORT_D (unsigned int*)&TRISD
		#define IOPORT_E (unsigned int*)&TRISE
		#define IOPORT_F (unsigned int*)&TRISF
		#define IOPORT_G (unsigned int*)&TRISG

		extern inline void __attribute__((always_inline)) PORTSetBits(unsigned int *regBase, unsigned int bits)
		{
				PortRegMap *PortMap = (PortRegMap*)regBase;
				PortMap->lat |= bits;
		}

		extern inline void __attribute__((always_inline)) PORTClearBits(unsigned int *regBase, unsigned int bits)
		{
				PortRegMap *PortMap = (PortRegMap*)regBase;
				PortMap->lat &= ~bits;

		}

		extern inline unsigned int __attribute__((always_inline)) PORTReadBits(unsigned int *regBase, unsigned int bits)
		{
				PortRegMap *PortMap = (PortRegMap*)regBase;
				return(PortMap->lat & bits);
		}

		extern inline void __attribute__((always_inline)) PORTSetPinsDigitalOut(unsigned int *regBase, unsigned int bits)
		{
				PortRegMap *PortMap = (PortRegMap*)regBase;
				PortMap->tris &= ~bits;
		}
	#endif
#endif // #ifdef (__dsPIC33E__) || (__PIC24E__)

// ********************************************************************
// * IOS FOR THE SWITCHES (SIDE BUTTONS)
// ********************************************************************
typedef enum
{
    HW_BUTTON_PRESS = 0,
    HW_BUTTON_RELEASE = 1
}HW_BUTTON_STATE;
#define HardwareButtonInit()        (AD1PCFGSET = _AD1PCFG_PCFG1_MASK | _AD1PCFG_PCFG0_MASK | _AD1PCFG_PCFG3_MASK | _AD1PCFG_PCFG4_MASK | _AD1PCFG_PCFG15_MASK,\
	                                    CNPUESET = _CNPUE_CNPUE2_MASK | _CNPUE_CNPUE3_MASK | _CNPUE_CNPUE5_MASK | _CNPUE_CNPUE6_MASK | _CNPUE_CNPUE12_MASK)
#define GetHWButtonProgram()        (PORTBbits.RB15)
#define GetHWButtonScanDown()       (PORTBbits.RB3)
#define GetHWButtonScanUp()         (PORTBbits.RB1)  
#define GetHWButtonCR()             (PORTBbits.RB15)
#define GetHWButtonFocus()          (PORTBbits.RB0 & PORTBbits.RB4)

// ********************************************************************
// * MMB LEDs
// ********************************************************************
typedef enum {
    LED_2,
    LED_3,
    LED_4,
    LED_5,
    LED_10
} MMB_LED;
        
extern inline void __attribute__((always_inline)) SetLEDDirection(void) {
    PORTSetPinsDigitalOut(IOPORT_D, (BIT_1 | BIT_2 | BIT_3));
    PORTSetPinsDigitalOut(IOPORT_C, (BIT_1 | BIT_2));
}
        
extern inline void __attribute__((always_inline)) TurnLEDOn(MMB_LED led) {
    if(led == LED_2)        PORTSetBits(IOPORT_D, BIT_1);
    if(led == LED_3)        PORTSetBits(IOPORT_D, BIT_2);
    if(led == LED_4)        PORTSetBits(IOPORT_D, BIT_3);
    if(led == LED_5)        PORTSetBits(IOPORT_C, BIT_1);
    if(led == LED_10)       PORTSetBits(IOPORT_C, BIT_2);
}
        
extern inline void __attribute__((always_inline)) TurnLEDOff(MMB_LED led) {
    if(led == LED_2)        PORTClearBits(IOPORT_D, BIT_1);
    if(led == LED_3)        PORTClearBits(IOPORT_D, BIT_2);
    if(led == LED_4)        PORTClearBits(IOPORT_D, BIT_3);
    if(led == LED_5)        PORTClearBits(IOPORT_C, BIT_1);
    if(led == LED_10)       PORTClearBits(IOPORT_C, BIT_2);
}
        
extern inline void __attribute__((always_inline)) ToggleLED(MMB_LED led) {
    if(led == LED_2)        PORTToggleBits(IOPORT_D, BIT_1);
    if(led == LED_3)        PORTToggleBits(IOPORT_D, BIT_2);
    if(led == LED_4)        PORTToggleBits(IOPORT_D, BIT_3);
    if(led == LED_5)        PORTToggleBits(IOPORT_C, BIT_1);
    if(led == LED_10)       PORTToggleBits(IOPORT_C, BIT_2);
}
        
extern inline void __attribute__((always_inline)) TurnLEDAllOn(void) {
        PORTSetBits(IOPORT_D, BIT_1);
        PORTSetBits(IOPORT_D, BIT_2);
        PORTSetBits(IOPORT_D, BIT_3);
        PORTSetBits(IOPORT_C, BIT_1);
        PORTSetBits(IOPORT_C, BIT_2);
}
        
extern inline void __attribute__((always_inline)) TurnLEDAllOff(void) {
        PORTClearBits(IOPORT_D, BIT_1);
        PORTClearBits(IOPORT_D, BIT_2);
        PORTClearBits(IOPORT_D, BIT_3);
        PORTClearBits(IOPORT_C, BIT_1);
        PORTClearBits(IOPORT_C, BIT_2);
}
// The MCHP25LC256 chip select signal, even if not used must be
// driven to high so it does not interfere with other SPI peripherals
// that uses the same SPI signals. 
#if defined(__dsPIC33FJ128GP804__) || defined(__PIC24HJ128GP504__)
	#define MCHP25LC256_CS_TRIS  TRISAbits.TRISA0
	#define MCHP25LC256_CS_LAT   LATAbits.LATA0
#elif defined(__PIC24FJ256GB110__)
	// This PIM has RD12 rerouted to RG0
	#define MCHP25LC256_CS_TRIS  TRISGbits.TRISG0
	#define MCHP25LC256_CS_LAT   LATGbits.LATG0
#else
	#define MCHP25LC256_CS_TRIS  TRISDbits.TRISD12
	#define MCHP25LC256_CS_LAT   LATDbits.LATD12
#endif
// ********************************************************************
// * HARDWARE PROFILE FOR DISPLAY CONTROLLER INTERFACE 
// ********************************************************************
#define DISP_ORIENTATION          90
#if (DISP_ORIENTATION == 0)	
    #define TOUCHSCREEN_RESISTIVE_SWAP_XY
    #define TOUCHSCREEN_RESISTIVE_CALIBRATION_SCALE_FACTOR   6
#elif (DISP_ORIENTATION == 90)	
    //#define TOUCHSCREEN_RESISTIVE_FLIP_X
    #define TOUCHSCREEN_RESISTIVE_CALIBRATION_SCALE_FACTOR   6
#elif (DISP_ORIENTATION == 180)	
    #define TOUCHSCREEN_RESISTIVE_SWAP_XY
    #define TOUCHSCREEN_RESISTIVE_FLIP_Y
    #define TOUCHSCREEN_RESISTIVE_CALIBRATION_SCALE_FACTOR   6
#elif (DISP_ORIENTATION == 270)	
    #define TOUCHSCREEN_RESISTIVE_FLIP_Y
    #define TOUCHSCREEN_RESISTIVE_CALIBRATION_SCALE_FACTOR   6
#endif	
#define DISP_HOR_RESOLUTION       240
#define DISP_VER_RESOLUTION       320
#define DISP_DATA_WIDTH           18
#define DISP_INV_LSHIFT
#define DISP_HOR_PULSE_WIDTH      25
#define DISP_HOR_BACK_PORCH       5
#define DISP_HOR_FRONT_PORCH      10
#define DISP_VER_PULSE_WIDTH      4
#define DISP_VER_BACK_PORCH       0
#define DISP_VER_FRONT_PORCH      2
#define GFX_LCD_TYPE              GFX_LCD_TFT
#define USE_TCON_SSD1289
#define USE_TCON_MODULE
#define USE_GFX_PMP
#define PMP_DATA_SETUP_TIME       (18)    
#define PMP_DATA_WAIT_TIME        (82)
#define PMP_DATA_HOLD_TIME        (0) 
#define BACKLIGHT_ENABLE_LEVEL    0
#define BACKLIGHT_DISABLE_LEVEL   1
#define USE_BITMAP_SD
#define SD_IMAGEDIR "\\img"
#include "PutImageFromSD.h"




// VGDD_MPLABX_WIZARD_END_SECTION *** DO NOT DELETE THIS LINE! ***

/*********************************************************************
* RTCC DEFAULT INITIALIZATION (these are values to initialize the RTCC
*********************************************************************/
#define RTCC_DEFAULT_DAY        18      // 18th
#define RTCC_DEFAULT_MONTH      01      // January
#define RTCC_DEFAULT_YEAR       12      // 2012
#define RTCC_DEFAULT_WEEKDAY    02      // Tuesday
#define RTCC_DEFAULT_HOUR       10      // 10:10:01
#define RTCC_DEFAULT_MINUTE     10
#define RTCC_DEFAULT_SECOND     01


#endif // __HARDWARE_PROFILE_H

