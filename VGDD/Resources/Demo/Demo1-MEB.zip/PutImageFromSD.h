#ifndef _PUTIMAGEFROMSD_H
#define _PUTIMAGEFROMSD_H

#include "Graphics/Primitive.h"
#include "Graphics/DisplayDriver.h"

#if defined(USE_BITMAP_SD)

#ifndef USE_BITMAP_EXTERNAL
	#define USE_BITMAP_EXTERNAL	
#endif

#define BINBMP_ON_SDFAT 0x0100

typedef struct {
    WORD type;      // BINBMP_ON_SDFAT or BINBMP_ON_SD_RAW
    char *filename; // pointer to filename
} IMAGE_ON_SD;

#ifdef USE_DRV_GETIMAGEWIDTH
SHORT GetImageWidth(void *bitmap);
#endif
#ifdef USE_DRV_GETIMAGEHEIGHT
SHORT GetImageHeight(void *bitmap);
#endif

#ifdef USE_DRV_PUTIMAGE
WORD ExternalMemoryCallback(IMAGE_EXTERNAL *memory, LONG offset, WORD nCount, void *buffer);
#endif

WORD PutImageFromSD(SHORT left, SHORT top, void *bitmap, BYTE stretch);

extern void PutImage1BPPExt(SHORT left, SHORT top, void *bitmap, BYTE stretch);
extern void PutImage4BPPExt(SHORT left, SHORT top, void *bitmap, BYTE stretch);
extern void PutImage8BPPExt(SHORT left, SHORT top, void *bitmap, BYTE stretch);
extern void PutImage16BPPExt(SHORT left, SHORT top, void *bitmap, BYTE stretch);

#endif // defined(USE_DRV_PUTIMAGE) && defined(USE_BITMAP_SD)
#endif // ifndef _PUTIMAGEFROMSD_H

