/*****************************************************************************
 *  Module for Microchip Graphics Library
 *  Large Bitmaps on SD handler
 *  This module takes care of handling Putimage calls in order to load bitmaps
 *  from SD/MMC memory card.
 *
 * Requisites:
 *  The following defines should be placed in HardwareProfile.h AFTER the other
 *  display defines (DISPLAY_CONTROLLER, DISP_ORIENTATION, DISP_HOR_RESOLUTION...)
 *
 * #define USE_BITMAP_SD
 * #define USE_DRV_GETIMAGEWIDTH
 * #define USE_DRV_GETIMAGEHEIGHT
 * #define USE_DRV_PUTIMAGE
 * #define SD_IMAGEDIR "\\img" // replace img with your directory
 * #ifdef _GRAPHICS_H
 * #include "PutImageFromSD.h"
 * #endif
 *
 *****************************************************************************
 * FileName:        PutImageFromSD.c
 * Dependencies:    Graphics.h HardwareProfile.h FSIO.h
 * Processor:       PIC24, PIC32
 * Compiler:        MPLAB C30, MPLAB C32
 * Linker:          MPLAB LINK30, MPLAB LINK32
 * Company:         VirtualFab
 *
 * Software License Agreement
 *
 * Copyright (c) 2011 VirtualFab  All rights reserved.
 * VirtualFab licenses to you the right to use, modify, copy and distribute
 * this Software as you wish
 *
 * SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY
 * OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR
 * PURPOSE. IN NO EVENT SHALL VIRTUALFAB OR ITS LICENSORS BE LIABLE OR
 * OBLIGATED UNDER CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION,
 * BREACH OF WARRANTY, OR OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT
 * DAMAGES OR EXPENSES INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL,
 * INDIRECT, PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA,
 * COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY
 * CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
 * OR OTHER SIMILAR COSTS.
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * VirtualFab           2011/06/17	Version 1.0 release
 *                      2012/04/23      Version 1.1 Release - not failing if media not mounted
 *****************************************************************************/

#include "MDD File System/FSIO.h"
#include "PutImageFromSD.h"

#if defined(USE_BITMAP_SD)

FSFILE *SDImgFileHandler = NULL;
IMAGE_ON_SD *SDImgCurrent = NULL;

/*********************************************************************
 * Function: WORD ExternalMemoryCallback(IMAGE_EXTERNAL *memory, LONG offset, WORD nCount, void *buffer)
 *
 * PreCondition: FSInit() already done
 *
 * Input: memory - The pointer to image object for the Bitmap to read
 *        offset - start position in the file to be read
 *        nCount - number of bytes to read
 *        buffer - Pointer to the buffer
 *
 * Output: number of bytes read
 *         If error: returns 0xffff
 *
 * Side Effects: none
 *
 * Overview: Reads image from SD and outputs image starting from left,top coordinates
 *
 * Note: image must be located on SD card
 *
 ********************************************************************/
WORD ExternalMemoryCallback(IMAGE_EXTERNAL *memory, LONG offset, WORD nCount, void *buffer) {
    IMAGE_ON_SD *img;
    char *ImageName;
    extern DISK gDiskData;

    if (gDiskData.mount == FALSE) {
        return (0xffff);
    }

    img = (IMAGE_ON_SD *) memory;
    if (SDImgCurrent != img) {
        SDImgCurrent = img;
        if (SDImgFileHandler != NULL) {
            FSfclose(SDImgFileHandler);
        }
        ImageName = img->filename;
        if (FSchdir(SD_IMAGEDIR) != 0) {
            return (0xffff);
        }
        // Open image file on SD
        SDImgFileHandler = FSfopen(ImageName, FS_READ);
        if (SDImgFileHandler == NULL)
            return (0xffff);
    }
    if (FSfseek(SDImgFileHandler, offset, SEEK_SET) != 0) // Seek from start of file
        return (0xffff);

    if (FSfread(buffer, 1, nCount, SDImgFileHandler) != nCount)
        return (0xffff);

    return (nCount);
}

/*********************************************************************
 * Function: WORD PutImage(SHORT left, SHORT top, void* image, BYTE stretch)
 *
 * PreCondition: none
 *
 * Input: left,top - left top image corner,
 *        image - image pointer,
 *        stretch - image stretch factor
 *
 * Output: For NON-Blocking configuration:
 *         - Returns 0 when device is busy and the image is not yet completely drawn.
 *         - Returns 1 when the image is completely drawn.
 *         For Blocking configuration:
 *         - Always return 1.
 *
 * Side Effects: none
 *
 * Overview: outputs image starting from left,top coordinates
 *
 * Note: image must be located in flash
 *
 ********************************************************************/
WORD PutImage(SHORT left, SHORT top, void *image, BYTE stretch) {
    FLASH_BYTE *flashAddress;
    BYTE colorDepth;
    WORD colorTemp;
    WORD resType;

#if defined(USE_COMP_RLE) 
    GFX_IMAGE_HEADER *pimghdr = (GFX_IMAGE_HEADER *) image;
#endif

#ifndef USE_NONBLOCKING_CONFIG
    while (IsDeviceBusy() != 0) Nop();

    /* Ready */
#else
    if (IsDeviceBusy() != 0)
        return (0);
#endif

    // Save current color
    colorTemp = GetColor();
    resType = *((WORD *) image);

#ifdef USE_BITMAP_SD
    if (resType == BINBMP_ON_SDFAT) {
        PutImageFromSD(left, top, image, stretch);
        SetColor(colorTemp);
        return (1);
    }
#endif

    switch (resType & (GFX_MEM_MASK | GFX_COMP_MASK)) {


#ifdef USE_COMP_RLE
#ifdef USE_BITMAP_FLASH
        case (FLASH | COMP_RLE):

            // Image address
            flashAddress = pimghdr->LOCATION.progByteAddress;
            // Read color depth
            colorDepth = pimghdr->colorDepth;

            // Draw picture
            switch (colorDepth) {
#if (COLOR_DEPTH >= 4)
                case 4:
                    PutImageRLE4BPP(left, top, flashAddress, stretch);
                    break;
#endif

#if (COLOR_DEPTH >= 8)
                case 8:
                    PutImageRLE8BPP(left, top, flashAddress, stretch);
                    break;
#endif

                default: break;
            }
            break;
#endif //#ifdef USE_BITMAP_FLASH

#ifdef USE_BITMAP_EXTERNAL
        case (EXTERNAL | COMP_RLE):

            // Get color depth
            ExternalMemoryCallback(image, 1, 1, &colorDepth);

            // Draw picture
            switch (colorDepth) {
#if (COLOR_DEPTH >= 4)
                case 4:
                    PutImageRLE4BPPExt(left, top, image, stretch);
                    break;
#endif

#if (COLOR_DEPTH >= 8)
                case 8:
                    PutImageRLE8BPPExt(left, top, image, stretch);
                    break;
#endif

                default: break;
            }
            break;
#endif //#ifdef USE_BITMAP_EXTERNAL
#endif // #ifdef USE_COMP_RLE

#ifdef USE_BITMAP_FLASH

        case (FLASH | COMP_NONE):


            flashAddress = ((IMAGE_FLASH *) image)->address; // Image address


            colorDepth = *(flashAddress + 1); // Read color depth

            // Draw picture
            switch (colorDepth) {
                case 1:
                    PutImage1BPP(left, top, flashAddress, stretch);
                    break;

#if (COLOR_DEPTH >= 4)
                case 4:
                    PutImage4BPP(left, top, flashAddress, stretch);
                    break;
#endif

#if (COLOR_DEPTH >= 8)
                case 8:
                    PutImage8BPP(left, top, flashAddress, stretch);
                    break;
#endif

#if (COLOR_DEPTH == 16)
                case 16:
                    PutImage16BPP(left, top, flashAddress, stretch);
                    break;
#endif

                default: break;

            }

            break;
#endif // #ifdef USE_BITMAP_FLASH

#ifdef USE_BITMAP_EXTERNAL

        case (EXTERNAL | COMP_NONE):

            // Get color depth
            if(ExternalMemoryCallback(image, 1, 1, &colorDepth)==0xffff){
                return 1;
            }

            // Draw picture
            switch (colorDepth) {
                case 1:
                    PutImage1BPPExt(left, top, image, stretch);
                    break;

#if (COLOR_DEPTH >= 4)
                case 4:
                    PutImage4BPPExt(left, top, image, stretch);
                    break;
#endif

#if (COLOR_DEPTH >= 8)
                case 8:
                    PutImage8BPPExt(left, top, image, stretch);
                    break;
#endif

#if (COLOR_DEPTH == 16)
                case 16:
                    PutImage16BPPExt(left, top, image, stretch);
                    break;
#endif

                default: break;
            }

            break;
#endif //#ifdef USE_BITMAP_EXTERNAL

#if defined (GFX_USE_DISPLAY_CONTROLLER_MCHP_DA210)
#ifdef USE_COMP_IPU
        case (FLASH | COMP_IPU):
        case (EXTERNAL | COMP_IPU):
        case (EDS_EPMP | COMP_IPU):
#endif // #ifdef USE_COMP_IPU
        case (EDS_EPMP | COMP_NONE):

            // this requires special processing of images in Extended Data Space
            // call the driver specific function to perform the processing
            PutImageDrv(left, top, image, stretch);
            break;

#endif //#if defined (__PIC24FJ256DA210__)

        default:
            break;
    }

    // Restore current color
    SetColor(colorTemp);
    return (1);
}

/*********************************************************************
 * Function: WORD PutImageFromSD(char *ImageName, SHORT left, SHORT top, void* bitmap, BYTE stretch)
 *
 * PreCondition: None
 *
 * Input: 
 *      left,top - left top image corner,
 *     ImageName - The filename for the Bitmap in binary format
 *       stretch - image stretch factor
 *
 * Output: For NON-Blocking configuration:
 *         - Returns 0 when device is busy and the image is not yet completely drawn.
 *         - Returns 1 when the image is completely drawn.
 *         For Blocking configuration:
 *         - Always return 1.
 *         If error: returns 2
 *
 * Side Effects: none
 *
 * Overview: Reads image from SD and outputs image starting from left,top coordinates
 *
 * Note: image must be located on SD card
 *
 ********************************************************************/

/* */
WORD PutImageFromSD(SHORT left, SHORT top, void *bitmap, BYTE stretch) {
    BYTE colorDepth;

    // Get color depth
    if(ExternalMemoryCallback(bitmap, 1, 1, &colorDepth)==0xffff){
        return 1;
    }

    // Draw picture
    switch (colorDepth) {
        case 1: PutImage1BPPExt(left, top, bitmap, stretch);
            break;
        case 4: PutImage4BPPExt(left, top, bitmap, stretch);
            break;
        case 8: PutImage8BPPExt(left, top, bitmap, stretch);
            break;
        case 16: PutImage16BPPExt(left, top, bitmap, stretch);
            break;
        default: break;
    }

    // Close File
    FSfclose(SDImgFileHandler);
    SDImgFileHandler = NULL;
    SDImgCurrent = NULL;
    return (1);
}

/*********************************************************************
 * Function: SHORT GetImageWidth(void* bitmap)
 *
 * PreCondition: none
 *
 * Input: bitmap - image pointer
 *
 * Output: none
 *
 * Side Effects: none
 *
 * Overview: returns image width
 *
 * Note: none
 *
 ********************************************************************/
SHORT GetImageWidth(void *bitmap) {
#if (defined USE_BITMAP_EXTERNAL) || defined(USE_BITMAP_SD)

    SHORT width;
#endif
    switch (*((SHORT *) bitmap)) {
#ifdef USE_BITMAP_FLASH

        case FLASH:
            return (*((FLASH_WORD *) ((IMAGE_FLASH *) bitmap)->address + 2));
#endif
#if (defined USE_BITMAP_EXTERNAL) || defined(USE_BITMAP_SD)

        case BINBMP_ON_SDFAT:
        case EXTERNAL:
            if (ExternalMemoryCallback(bitmap, 4, 2, &width) == 0xffff) {
                return 0;
            } else {
                return (width);
            }
#endif

        default:
            return (0);
    }
}

/*********************************************************************
 * Function: SHORT GetImageHeight(void* bitmap)
 *
 * PreCondition: none
 *
 * Input: bitmap - image pointer
 *
 * Output: none
 *
 * Side Effects: none
 *
 * Overview: returns image height
 *
 * Note: none
 *
 ********************************************************************/
SHORT GetImageHeight(void *bitmap) {
#if (defined USE_BITMAP_EXTERNAL) || defined(USE_BITMAP_SD)

    SHORT height;
#endif
    switch (*((SHORT *) bitmap)) {

#ifdef USE_BITMAP_FLASH

        case FLASH:
            return (*((FLASH_WORD *) ((IMAGE_FLASH *) bitmap)->address + 1));
#endif
#if (defined USE_BITMAP_EXTERNAL) || defined(USE_BITMAP_SD)

        case BINBMP_ON_SDFAT:
        case EXTERNAL:
            if (ExternalMemoryCallback(bitmap, 2, 2, &height) == 0xffff) {
                return 0;
            } else {
                return (height);
            }
#endif


        default:
            return (0);
    }
}
#endif // defined(USE_BITMAP_SD)
